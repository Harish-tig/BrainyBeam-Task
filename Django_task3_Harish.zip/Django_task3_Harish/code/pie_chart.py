import pandas as pd
import matplotlib.pyplot as plt

# Step 1: Read CSV
df = pd.read_csv('products.csv')

# Step 2: Extract data
products = df['Product']
stock = df['Stock']

# Step 3: Create pie chart
plt.figure(figsize=(8, 8), dpi=200)
plt.pie(stock, labels=products, autopct='%1.1f%%', startangle=140,radius=0.7)
plt.title("Product Stock Distribution")
plt.axis('equal')  # Make the pie chart circular
plt.tight_layout()
plt.legend(loc= "upper left")

# Step 4: Save and show the pie chart
plt.savefig('product_stock_pie_chart.png', dpi=300)
plt.show()
