from django.urls import path
from . import views

urlpatterns = [
    path("", views.say_hello),
    path("create_user/", views.create_user_and_profile,name = 'create_user_and_profile' )
]