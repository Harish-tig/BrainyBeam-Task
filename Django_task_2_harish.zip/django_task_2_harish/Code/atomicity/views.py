from django.shortcuts import render
from django.http import HttpResponse
from django.db import transaction
from django.contrib.auth.models import User

def say_hello(request):
    return HttpResponse("hello world")

from django.shortcuts import render
from django.contrib.auth.models import User
from .models import Profile
from django.db import transaction, IntegrityError
from django.http import HttpResponse

@transaction.atomic
def create_user_and_profile(request):
    if request.method == 'POST':
        try:
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            phone = request.POST.get('phone')
            address = request.POST.get('address')

            # Step 1: Create User
            user = User.objects.create_user(username=username, email=email, password=password)
            #for simply city
            Profile.objects.create(user=user, phone=phone, address=address)
            #reffering from models
            return HttpResponse(f"{user.username}'s account and profile created successfully!")

        except Exception as e:
            # If anything goes wrong, changes will be rolled back
            return HttpResponse(f"Error: {str(e)}")
    else:
        return render(request, 'create_user.html')  # a simple form template