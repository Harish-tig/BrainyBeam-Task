import os
import random
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
private_key_path = r"C:\Users\nadar\OneDrive\Desktop\keys\private_key.pem"
public_key_path = r"C:\Users\nadar\OneDrive\Desktop\keys\public_key.pem"

with open(private_key_path, "rb") as f:
    private_key = serialization.load_pem_private_key(f.read(), password=None)

with open(public_key_path, "rb") as f:
    public_key = serialization.load_pem_public_key(f.read())

def generate_otp():
    letters = random.sample('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 2)
    special_chars = random.sample('!@#$%&*', 2)
    digits = random.sample('0123456789', 2)
    otp_list = letters + special_chars + digits
    random.shuffle(otp_list)
    return ''.join(otp_list)

otp = generate_otp()
print("Generated OTP:", otp)

encrypted_otp = public_key.encrypt(
    otp.encode(),
    padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    )
)
print("Encrypted OTP (bytes):", encrypted_otp)

decrypted_otp = private_key.decrypt(
    encrypted_otp,
    padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    )
)
print("Decrypted OTP:", decrypted_otp.decode())


